export const RENDER_KEY = {
    TEXT: 'text',
    STREAM: 'stream',
    AUDIO: 'audio',
    STREAM_AUDIO: 'streamAudio',
    INTERRPUT: 'interrupt',
    EMPTY: ''
};

 export const STREAM_TEXT = [
    '第一段，动力电池产业的发展备',
    '第一段，动力电池产业的发展备',
    '体能量密度今天天',
    '气',
    '很好'
];